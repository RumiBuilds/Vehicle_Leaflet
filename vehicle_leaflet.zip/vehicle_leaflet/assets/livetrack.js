// Global variables
var map = null;
var liveMarkers = {};
var vehicleHistory = {};
var infoWindow = null;
var baseUrl = $('#base').val();

// Initialize the map when window loads
window.onload = function() {
    // Initialize map
    map = L.map('liveTrackingMap', {
        gestureHandling: true
    }).setView([52.696361078274485, -111.4453125], 3);

    // Add base tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    // Get current position if available
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            document.cookie = "latitude=" + position.coords.latitude;
            document.cookie = "longitude=" + position.coords.longitude;
        });
    }

    // Start live tracking
    livetracking();
    window.setInterval(livetracking, 15000);
};

// Vehicle type to icon mapping
var vehicleIcons = {
    'MOTORCYCLE': L.divIcon({
        html: '<i class="fas fa-motorcycle"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon motorcycle'
    }),
    'BICYCLE': L.divIcon({
        html: '<i class="fas fa-bicycle"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon bicycle'
    }),
    'CAR': L.divIcon({
        html: '<i class="fas fa-car"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon car'
    }),
    'TRUCK': L.divIcon({
        html: '<i class="fas fa-truck"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon truck'
    }),
    'BUS': L.divIcon({
        html: '<i class="fas fa-bus"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon bus'
    }),
    'TAXI': L.divIcon({
        html: '<i class="fas fa-taxi"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon taxi'
    }),
    'default': L.divIcon({
        html: '<i class="fas fa-truck"></i>',
        iconSize: [24, 24],
        className: 'vehicle-icon default'
    })
};

function livetracking() {
    var path = $("#group").attr("data-name") != 0 ?
        baseUrl + "/api/currentpositions?gr=" + $("#group").attr("data-name") :
        baseUrl + "/api/currentpositions";

    $.ajax({
        type: "GET",
        url: path,
        dataType: 'json',
        cache: false,
        success: function(result) {
            if (result.status == 1) {
                updateVehicleMarkers(result.data);
            } else {
                alertmessage(result.message, 2);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Unexpected error:', errorThrown);
        }
    });
}

function updateVehicleMarkers(markers) {
    var bounds = L.latLngBounds();
    var currentTime = new Date().getTime();

    markers.forEach(function(markerData) {
        var latLng = L.latLng(
            parseFloat(markerData.latitude),
            parseFloat(markerData.longitude)
        );

        bounds.extend(latLng);

        // Get or create marker
        if (!liveMarkers[markerData.v_id]) {
            createNewMarker(markerData, latLng);
        } else {
            updateExistingMarker(markerData, latLng);
        }

        // Update vehicle history trail
        updateVehicleHistory(markerData, latLng);
    });

    // Fit map to show all markers if there are multiple
    if (Object.keys(liveMarkers).length > 1) {
        map.fitBounds(bounds.pad(0.1));
    }
}

function createNewMarker(markerData, latLng) {
    var icon = vehicleIcons[markerData.v_type] || vehicleIcons['default'];
    
    // Set icon color
    if (markerData.v_color) {
        icon.options.html = icon.options.html.replace('>', 
            ` style="color: ${markerData.v_color}">`);
    }

    var marker = L.marker(latLng, {
        icon: icon,
        rotationAngle: markerData.heading || 0,
        zIndexOffset: 1000
    });

    // Create popup content
    var popupContent = `
        <div class="vehicle-popup">
            <b>Name: </b>${markerData.v_name}<br>
            <b>Speed: </b>${Math.round(markerData.speed)} Km/h<br>
            <b>Updated On: </b>${markerData.time}
        </div>
    `;

    marker.bindPopup(popupContent);
    marker.addTo(map);
    
    // Store reference to marker
    liveMarkers[markerData.v_id] = marker;
}

function updateExistingMarker(markerData, latLng) {
    var marker = liveMarkers[markerData.v_id];
    marker.setLatLng(latLng);
    
    // Update rotation if heading data exists
    if (markerData.heading) {
        marker.setRotationAngle(markerData.heading);
    }
    
    // Update popup content
    var popupContent = `
        <div class="vehicle-popup">
            <b>Name: </b>${markerData.v_name}<br>
            <b>Speed: </b>${Math.round(markerData.speed)} Km/h<br>
            <b>Updated On: </b>${markerData.time}
        </div>
    `;
    marker.setPopupContent(popupContent);
}

function updateVehicleHistory(markerData, latLng) {
    if (!vehicleHistory[markerData.v_id]) {
        vehicleHistory[markerData.v_id] = L.polyline([], {
            color: markerData.v_color || '#3388ff',
            weight: 3,
            opacity: 0.7
        }).addTo(map);
    }
    
    var history = vehicleHistory[markerData.v_id];
    var currentPath = history.getLatLngs();
    currentPath.push(latLng);
    history.setLatLngs(currentPath);
}

function alertmessage(msg, type) {
    var toastOptions = {
        heading: type == 1 ? 'Success' : 'Error',
        text: msg,
        loader: true,
        position: 'top-center',
        loaderBg: type == 1 ? '#2196f3' : '#f44336'
    };

    if (type == 1) {
        toastOptions.icon = 'info';
        toastOptions.afterHidden = function() {
            location.reload();
        };
    } else {
        toastOptions.icon = 'error';
    }

    $.toast(toastOptions);
}
// Extend Number prototype for km/h conversion
Number.prototype.toKmH = function() {
    return Math.round(this * 3600 / 10) / 100;
};

// Global variables
var historyMap = null;
var historyMarkers = [];
var historyPolylines = [];
var historyZoomLevel = 15;

// Clear all history markers and polylines
function clearHistoryOverlays() {
    historyMarkers.forEach(function(marker) {
        historyMap.removeLayer(marker);
    });
    historyMarkers = [];
    
    historyPolylines.forEach(function(polyline) {
        historyMap.removeLayer(polyline);
    });
    historyPolylines = [];
}

// Initialize the tracking form submission
$("#track").on("submit", function(e) {
    if ($('#t_vechicle').val() === '') {
        return;
    }
    e.preventDefault();
    
    // Initialize the map if not already done
    if (!historyMap) {
        historyMap = L.map('trackingMap').setView([52.696361078274485, -111.4453125], historyZoomLevel);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19
        }).addTo(historyMap);
        
        // Store zoom level changes
        historyMap.on('zoomend', function() {
            historyZoomLevel = historyMap.getZoom();
        });
    }
    
    clearHistoryOverlays();
    
    var path = $('#base').val() + "/api/positions";
    
    $.ajax({
        type: "post",
        data: $("#track").serialize(),
        url: path,
        dataType: 'json',
        success: function(result) {
            if (result.data.length >= 1) {
                displayHistoryRoute(result.data);
            } else {
                alertmessage('No data to show in map', 2);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Unexpected error:', errorThrown);
            alertmessage('Error loading tracking data', 2);
        }
    });
});

function displayHistoryRoute(locations) {
    var routeCoordinates = [];
    var bounds = L.latLngBounds();
    
    // Create markers for each point
    locations.forEach(function(location, index) {
        var latLng = L.latLng(
            parseFloat(location.latitude),
            parseFloat(location.longitude)
        );
        
        bounds.extend(latLng);
        routeCoordinates.push(latLng);
        
        // Determine marker icon
        var iconUrl;
        if (index === 0) {
            iconUrl = 'assets/marker/marker-green.png'; // Start point
        } else if (index === locations.length - 1) {
            iconUrl = 'assets/marker/marker-red.png'; // End point
        } else {
            iconUrl = 'assets/marker/marker-white.png'; // Intermediate points
        }
        
        var icon = L.icon({
            iconUrl: iconUrl,
            iconSize: [32, 32],
            iconAnchor: [16, 16],
            popupAnchor: [0, -16]
        });
        
        var marker = L.marker(latLng, {
            icon: icon
        }).addTo(historyMap);
        
        // Add popup with location info
        var popupContent = `
            <div>
                <b>Speed:</b> ${parseInt(location.speed)} km/hr<br>
                <b>Time:</b> ${location.time}<br>
                ${location.comment ? '<b>Comment:</b> ' + location.comment + '<br>' : ''}
            </div>
        `;
        
        marker.bindPopup(popupContent);
        historyMarkers.push(marker);
    });
    
    // Create the route polyline
    var routePolyline = L.polyline(routeCoordinates, {
        color: "#61EA1a",
        weight: 5,
        opacity: 0.8,
        smoothFactor: 1
    }).addTo(historyMap);
    
    historyPolylines.push(routePolyline);
    
    // Fit map to show the entire route
    historyMap.fitBounds(bounds, {
        padding: [50, 50] // Add some padding around the bounds
    });
}

// Existing alertmessage function (unchanged)
function alertmessage(msg, type) {
    var toastOptions = {
        heading: type == 1 ? 'Success' : 'Error',
        text: msg,
        loader: true,
        position: 'top-center',
        loaderBg: type == 1 ? '#2196f3' : '#f44336'
    };

    if (type == 1) {
        toastOptions.icon = 'info';
        toastOptions.afterHidden = function() {
            location.reload();
        };
    } else {
        toastOptions.icon = 'error';
    }

    $.toast(toastOptions);
}
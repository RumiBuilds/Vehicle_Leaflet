// setTimeout(function() {
//   $('#alertmessage').fadeOut('slow');
// }, 5000); 

// $(document).ready(function() {   
// $('.datepicker').datepicker({
//         format: 'yyyy-mm-dd',
//         autoclose: true,
//         todayHighlight: true
// });
// 	$('#t_trip_fromlocation').on('click', function() {
// 		if($("#t_created_by").val().length == 0) {
// 		   $("#ermsg").html('<div id="alertmessage" class="col-md-12"><div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><span style="margin-left: 40%;">Please login before trying to book..</span></div></div>');
// 		   setTimeout(function() {
// 		        $("#alertmessage").hide().data("active", false);
// 		    }, 10000);
// 		}
// 	});
//   var input = document.getElementById('t_trip_fromlocation');
//   new google.maps.places.Autocomplete(input);
//   var t_trip_tolocation = document.getElementById('t_trip_tolocation');
//   new google.maps.places.Autocomplete(t_trip_tolocation);
	

// });

// Handle alert timeout
setTimeout(function() {
    $('#alertmessage').fadeOut('slow');
}, 5000); 

// Initialize datepicker
$(document).ready(function() {   
    $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true
    });
    
    // Check login status when clicking location fields
    $('#t_trip_fromlocation, #t_trip_tolocation').on('click', function() {
        if($("#t_created_by").val().length == 0) {
            $("#ermsg").html(`
                <div id="alertmessage" class="col-md-12">
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <span style="margin-left: 40%;">Please login before trying to book..</span>
                    </div>
                </div>
            `);
            setTimeout(function() {
                $("#alertmessage").hide().data("active", false);
            }, 10000);
        }
    });
    
    // Handle switch button for locations
    $('#switchButton').on('click', function() {
        const fromLocation = $('#t_trip_fromlocation').val();
        const fromLat = $('#t_trip_fromlat').val();
        const fromLng = $('#t_trip_fromlog').val();
        
        $('#t_trip_fromlocation').val($('#t_trip_tolocation').val());
        $('#t_trip_fromlat').val($('#t_trip_tolat').val());
        $('#t_trip_fromlog').val($('#t_trip_tolog').val());
        
        $('#t_trip_tolocation').val(fromLocation);
        $('#t_trip_tolat').val(fromLat);
        $('#t_trip_tolog').val(fromLng);
        
        // Update map markers if both locations exist
        if (fromMarker && toMarker) {
            const fromLatLng = fromMarker.getLatLng();
            const toLatLng = toMarker.getLatLng();
            
            fromMarker.setLatLng(toLatLng);
            fromMarker.setPopupContent("<b>From:</b> " + $('#t_trip_fromlocation').val());
            
            toMarker.setLatLng(fromLatLng);
            toMarker.setPopupContent("<b>To:</b> " + $('#t_trip_tolocation').val());
            
            calculateDistance();
        }
    });
    
    // Form validation
    $('#booking').on('submit', function(e) {
        if (!$('#t_trip_fromlat').val() || !$('#t_trip_tolat').val()) {
            e.preventDefault();
            alert('Please select valid locations from the suggestions');
        }
    });
});

// Global function to calculate distance (accessible from map script)
function calculateDistance() {
    // This will use the implementation from the map script
    if (typeof window.calculateDistance === 'function') {
        window.calculateDistance();
    }
}
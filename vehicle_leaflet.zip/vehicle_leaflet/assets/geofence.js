// Global variables
var map;
var drawnItems;
var selectedShape;
var searchControl;

// Initialize the map when window loads
window.addEventListener("load", initialize);

function initialize() {
  // 1. Initialize the map
  map = L.map("map", {
    gestureHandling: true,
  }).setView([24.8998373, 91.8258764], 12);

  // Add base tile layer (OpenStreetMap)
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
  }).addTo(map);

  // 2. Initialize the feature group to store drawn items
  drawnItems = new L.FeatureGroup();
  map.addLayer(drawnItems);

  // 3. Initialize the draw control
  initializeDrawingTools();

  // 4. Initialize search functionality
  initializeSearch();

  // 5. Set up event listeners
  setupEventListeners();

  // 6. Initialize delete button
  document
    .getElementById("delete-button")
    .addEventListener("click", deleteSelectedShape);
}

function initializeDrawingTools() {
  var drawControl = new L.Control.Draw({
    position: "topright",
    draw: {
      polygon: {
        shapeOptions: {
          color: "#3388ff",
          weight: 2,
          opacity: 1,
          fillColor: "#3388ff",
          fillOpacity: 0.45,
          clickable: true,
        },
        allowIntersection: false,
        showArea: true,
        metric: true,
        repeatMode: false,
      },
      marker: false,
      polyline: false,
      rectangle: false,
      circle: false,
      circlemarker: false,
    },
    edit: {
      featureGroup: drawnItems,
      remove: false,
    },
  });

  map.addControl(drawControl);
}

function initializeSearch() {
  const provider = new GeoSearch.OpenStreetMapProvider();

  searchControl = new GeoSearch.GeoSearchControl({
    provider: provider,
    style: "bar",
    showMarker: true,
    showPopup: false,
    marker: {
      icon: new L.Icon.Default(),
      draggable: false,
    },
    maxMarkers: 1,
    retainZoomLevel: false,
    animateZoom: true,
    autoClose: true,
    searchLabel: "Search location",
    keepResult: true,
  });

  map.addControl(searchControl);
}

function setupEventListeners() {
  // Handle drawing creation
  map.on(L.Draw.Event.CREATED, function (e) {
    var layer = e.layer;
    layer.type = e.layerType;

    // Add to feature group
    drawnItems.addLayer(layer);

    // Add event listeners to the layer
    layer.on({
      click: function () {
        setSelection(layer);
      },
      dragend: function () {
        updateCurSelText(layer);
      },
    });

    setSelection(layer, true);
  });

  // Handle edits
  map.on(L.Draw.Event.EDITED, function (e) {
    var layers = e.layers;
    layers.eachLayer(function (layer) {
      updateCurSelText(layer);
    });
  });

  // Clear selection when starting to draw or edit
  map.on(L.Draw.Event.DRAWSTART, clearSelection);
  map.on(L.Draw.Event.EDITSTART, clearSelection);

  // Clear selection on map click
  map.on("click", clearSelection);
}

function setSelection(layer, isShape) {
  clearSelection();

  if (isShape) {
    // Style the selected shape
    layer.setStyle({
      color: "#ff0000",
      fillColor: "#ff0000",
      weight: 3,
    });

    // Bring to front
    layer.bringToFront();
  }

  selectedShape = layer;
}

function clearSelection() {
  if (selectedShape) {
    // Reset style for all shapes
    drawnItems.eachLayer(function (layer) {
      layer.setStyle({
        color: "#3388ff",
        fillColor: "#3388ff",
        weight: 2,
      });
    });

    selectedShape = null;
  }
}

function updateCurSelText(layer) {
  if (!layer || !layer.getLatLngs) return;

  var coordinates = [];
  var latLngs = layer.getLatLngs()[0]; // For polygon (outer ring)

  // Format coordinates for display or saving
  latLngs.forEach(function (latLng) {
    coordinates.push(latLng.lat + "," + latLng.lng);
  });

  // If you need to save these to a hidden input field
  document.getElementById("geo_area").value = coordinates.join(" , ");
}

function deleteSelectedShape() {
  if (selectedShape) {
    map.removeLayer(selectedShape);
    drawnItems.removeLayer(selectedShape);
    selectedShape = null;
    document.getElementById("geo_area").value = "";
  }
}

// Helper function to load existing geofences
function loadGeofence(coordinates) {
  clearSelection();

  // Convert coordinate string to LatLng array
  var latLngs = coordinates.split(" , ").map(function (point) {
    var parts = point.split(",");
    return L.latLng(parseFloat(parts[0]), parseFloat(parts[1]));
  });

  // Create and add polygon
  var polygon = L.polygon(latLngs, {
    color: "#3388ff",
    weight: 2,
    opacity: 1,
    fillColor: "#3388ff",
    fillOpacity: 0.45,
    draggable: true,
    editable: true,
  }).addTo(drawnItems);

  // Add event listeners
  polygon.on({
    click: function () {
      setSelection(polygon);
    },
    dragend: function () {
      updateCurSelText(polygon);
    },
    edit: function () {
      updateCurSelText(polygon);
    },
  });

  // Fit bounds to the polygon
  map.fitBounds(polygon.getBounds());
}

<!-- <!DOCTYPE html>
<html >
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
     <meta charset = "UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="description" content="">
      <meta name="author" content="">
      <title><?php 
         $data = sitedata();
         $total_segments = $this->uri->total_segments(); 
         echo ucwords(str_replace('_', ' ', 'Booking')).' | '.output($data['s_companyname']) ?></title>
      <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
      <link rel="stylesheet" href="<?= base_url(); ?>assets/frontend/bootstrap.min.css">
      <link rel="stylesheet" href="<?= base_url(); ?>assets/frontend/font-awesome.min.css">
      <link href="<?= base_url(); ?>assets/frontend/custom.css" rel="stylesheet">
      <script src="<?= base_url(); ?>assets/plugins/jquery/jquery_frnt.js"></script>
      <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/daterangepicker/daterangepicker.css">
      <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/datepicker/bootstrap-datepicker.min.css">
   </head>
   <body >
  <input type="hidden" id="base" value="<?php echo base_url(); ?>">
  
      <div class="tb_header">
         <div class="container">
            <div class="col-md-6" style="padding:0;">
               <div style="margin-top: 20px;"> <img heigth="80" width="50" src="<?= base_url().'assets/uploads/'.$data['s_logo'] ?>"> </div>
            </div>
            <div class="col-md-4" style="padding:0;">
            </div>
            <div class="col-md-2" style="padding:0;">
               <?php if(isset($this->session->userdata['session_data_fr']['c_name'])) { ?>
                  <div class="signin_up">
                  <ul>
                     <li>Welcome , <?= ucfirst($this->session->userdata['session_data_fr']['c_name']); ?> </li><br>
                     <li><a href="<?php echo base_url(); ?>frontendbooking/mybookings">My Bookings</a>  <span style="color:#f0a2a3;">/</span></li>
                     <li><a href="<?php echo base_url(); ?>frontendbooking/logout">Logout</a></li>
                  </ul>
               </div>
               <?php  } else { ?>
               <div class="signin_up">
                  <ul>
                     <li><a href="#myModals" data-toggle="modal" data-target="#myModals">Sign In</a>  <span style="color:#f0a2a3;">/</span></li>
                     <li><a href="#myModal" data-toggle="modal" data-target="#myModal">Sign Up</a></li>
                  </ul>
               </div>
            <?php  } ?>
            </div>
         </div>
         <div class="shadow">
            <hr class="border2">
            </hr>
         </div>
      </div>

      <div class="modal fade" id="myModals" role="dialog" data-backdrop="static" data-keyboard="false">
         <div class="modal-dialog">
            <button type="button" class="close_lft" data-dismiss="modal">&times;</button>
            <form id="login" method="post" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/login">
               <div class="login-block">
                  <h1>Login</h1>
                  <input type="text" required name="username" placeholder="Email" class ="username" id="username" required=""/>
                  <input type="password" required class="password" name="password" placeholder="Password" id="password" required=""/>
                  <button  type="submit" value="Login" style="position: relative;">Login</button>
                  <br>
                  
                  <div class="login_res" style="text-align:center;"></div>
                  <br>
                  <div class="sign_in"><a  data-dismiss="modal" href="#myModal" data-toggle="modal" data-target="#myModal">Sign Up</a></div>
               </div>
            </form>
         </div>
      </div>
      <div class="modal fade" id="myModal" role="dialog">
         <div class="modal-dialog">
            <button type="button" class="close_lft" data-dismiss="modal">&times;</button>
            <form id="signup" method="post" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/signup">
               <div class="login-block">
                  <h1>Sign Up</h1>
                  <input class="name" required id="c_name" name="c_name"  placeholder="Name" >
                  <input class="name" required id="c_mobile" name="c_mobile"  placeholder="Mobile" >
                  <input class="name" required id="c_email" name="c_email"  placeholder="Email(Username)" >
                  <input type="password" required class="name"  id="c_pwd" name="c_pwd"  placeholder="Password" >
                  <input class="name" required id="c_address" name="c_address"  placeholder="Address" >
                  <br>
                  <span class="terms_tb">By signing up, you agree to our <a class="cond_tb" href="#">Terms and Conditions.</a></span> <br>
                  <br>
                  <button  type="submit" value="Sign up" style="position: relative;">Sign UP</button>
                  <br>
                 
                  <div class="signup_res" style="text-align:center;"></div>
                  <br>
                  <div class="account"><a data-dismiss="modal" href="#myModals"data-toggle="modal" data-target="#myModals">Already have an account?</a></div>
                  <div class="sign_in"><a data-dismiss="modal" href="#myModals"data-toggle="modal" data-target="#myModals">Sign In</a></div>
               </div>
            </form>
         </div>
      </div>
      <div class="modal fade" id="myModalf" role="dialog">
         <div class="modal-dialog">
            <button type="button" class="close_lft" data-dismiss="modal">&times;</button>
            <form id="forgot" data-parsley-validate="">
               <div class="login-block">
                  <h1>Forgot Password</h1>
                  <input type="email" name="email" placeholder="Email" class="username"  data-parsley-required="true"/>
                  <input  type="button" value="RESET" style="position: relative;" onclick="Forgot()">
                  <br>
                  <div class="small_loader" style="text-align:center;display:none"></div>
                  <div class="forgot_res" style="text-align:center;"></div>
                  <br>
                  <div class="account"><a href="#">Already have an account?</a></div>
                  <div class="sign_in"><a data-dismiss="modal" href="#myModals"data-toggle="modal" data-target="#myModals">Sign In</a></div>
               </div>
            </form>
         </div>
      </div>
      <div class="container">
   
         <div class="row" style="min-height:400px;margin-top:120px;">
      <div class="row">
            <div class="col-md-12">
               <span id="ermsg"></span>
            <?php $successMessage = $this->session->flashdata('successmessage');  
           $warningmessage = $this->session->flashdata('warningmessage');                    
            if (isset($successMessage)) { echo '<div id="alertmessage" class="col-md-12">
                <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><span style="margin-left: 40%;">
                         '. $successMessage.'
                        </span></div>
                </div>'; } 
            if (isset($warningmessage)) { echo '<div id="alertmessage" class="col-md-12">
                <div class="alert alert-warning alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><span style="margin-left: 40%;">
                         '. $warningmessage.'
                        </span></div>
                </div>'; }    
            ?>
         </div>
         </div>
            


            <div class="col-md-6">
               <form id="booking" method="POST" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/book">
                  <section id="Search" class="LB XXCN  P20">
                     <h1 class="bookTic XCN TextSemiBold" ><?= output($data['s_companyname']); ?></h1>
                     <div class="searchRow clearfix">
                        <div class="LB">
                           <label class="inputLabel">From</label>
                           <input id="t_trip_fromlocation" name="t_trip_fromlocation" class="XXinput searching" placeholder="Enter From" type="text" tabindex="1" required/>
                        </div>
                        <span class="switchButton" id="switchButton"></span>
                        <div class="searchRight NoPaddingRight">
                           <label class="inputLabel">To</label>
                           <input id="t_trip_tolocation" name="t_trip_tolocation" class="XXinput searching" placeholder="Enter To" type="text" tabindex="2" required />
                        </div>
                     </div>
                    <div class="searchRow clearfix">
                        <div class="LB" style="margin-top: 0px;">
                           <label class="inputLabel">Vehicle Type</label>
                             <select style="height: 32px; margin-top: -1px;" required id="t_vechicle"  class="XXinput searching"  name="t_vechicle">
                            <option value="">Select vehicle</option>
                           <?php  foreach ($vechiclelist as $key => $vechiclelists) { ?>
                           <option  value="<?php echo output($vechiclelists['v_id']) ?>"><?php echo output($vechiclelists['v_name']).' - '. output($vechiclelists['v_registration_no']); ?></option>
                           <?php  } ?>
                           </select>
                        </div>
                        <div class="searchRight retJouney">
                           <label class="inputLabel">Date</label>
                          <input id="t_start_date" name="t_start_date" class="datepicker XXinput"  required placeholder="yyyy-mm-dd"  type="text" title="Date in the format yyyy-mm-dd" tabindex="3">
                        </div>
                     </div>
                     <input type="hidden" id="t_trip_fromlat" name="t_trip_fromlat" value="1">
                      <input type="hidden" id="t_totaldistance" name="t_totaldistance" value="">
                     <input type="hidden" id="t_trip_fromlog" name="t_trip_fromlog" value="1">
                     <input type="hidden" id="t_driver" name="t_driver" value="0">
                      <input type="hidden" id="t_type" name="t_type" value="singletrip">
                      <input type="hidden" id="t_trip_status" name="t_trip_status" value="yettoconfirm">
                     <input type="hidden" id="t_customer_id" name="t_customer_id" value="<?= (isset($this->session->userdata['session_data_fr']['c_id'])?$this->session->userdata['session_data_fr']['c_id']:''); ?>">
                     <input type="hidden" id="t_trip_tolat" name="t_trip_tolat" value="1">
                     <input type="hidden" id="t_trip_tolog" name="t_trip_tolog" value="1">
                     <input type="hidden" id="t_created_by" name="t_created_by" value="<?= (isset($this->session->userdata['session_data_fr']['c_id'])?$this->session->userdata['session_data_fr']['c_id']:''); ?>">
                      <input type="hidden" id="bookingemail" name="bookingemail" value="<?= (isset($this->session->userdata['session_data_fr']['c_email'])?$this->session->userdata['session_data_fr']['c_email']:''); ?>">
                                  <input type="hidden" id="t_created_date" name="t_created_date" value="<?php echo date('Y-m-d h:i:s'); ?>">

                     <button type="submit" class="RB Xbutton">Book Now</button>
                  </section>
               </form>
            </div>
            <div class="col-md-6">
               <div class="tb_bus">
                  <img width="500" height="300" src="<?= base_url(); ?>assets/uploads/fronendimg.jpg">
               </div>
            </div>
         </div>
      </div>
      <hr class="border2">
      </hr>
      <div class="container">
         <div class="row">
            <div class="tb_inner">
               <div class="col-md-9">
                  <div class="tb_footer">
                     <ul>
                        <li><a href="#">FAQ   &nbsp;|</a></li>
                        <li><a href="#">Contact Us   &nbsp;|</a></li>
                        <li><a href="#">Terms of Use   &nbsp;|</a></li>
                        <li><a href="#">Privacy Policy   &nbsp;</a></li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-3">
                  <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
               </div>
            </div>
         </div>
      </div>
      <script src="<?= base_url(); ?>assets/frontend/bootstrap.min.js"></script>
      <script src="<?= base_url(); ?>assets/plugins/datepicker/bootstrap-datepicker.min.js"></script>
      <script type="text/javascript" src="https://www.google.com/jsapi"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
       <script src="<?= base_url(); ?>assets/fronendbooking.js"></script>
       <script src="<?= base_url(); ?>assets/distance_calculator.js"></script>
   </body>
</html> -->




<!--
<!DOCTYPE html>
 <html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php 
        $data = sitedata();
        $total_segments = $this->uri->total_segments(); 
        echo ucwords(str_replace('_', ' ', 'Booking')).' | '.output($data['s_companyname']) ?></title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/frontend/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/frontend/font-awesome.min.css">
    <link href="<?= base_url(); ?>assets/frontend/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
    <style>
        #map {
            height: 400px;
            width: 100%;
            border-radius: 4px;
            box-shadow: 0 1px 5px rgba(0,0,0,0.2);
            margin-top: 10px;
        }
        .autocomplete-dropdown {
            position: absolute;
            background: white;
            z-index: 1000;
            width: calc(100% - 30px);
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ddd;
            display: none;
        }
        .autocomplete-item {
            padding: 8px;
            cursor: pointer;
        }
        .autocomplete-item:hover {
            background-color: #f5f5f5;
        }
        .route-info {
            margin-top: 10px;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<input type="hidden" id="base" value="<?php echo base_url(); ?>">

<div class="tb_header">
</div>

<div class="modal fade" id="myModals" role="dialog" data-backdrop="static" data-keyboard="false">
</div>

<div class="container">
    <div class="row" style="min-height:400px;margin-top:120px;">
        <div class="row">
            <div class="col-md-12">
                <span id="ermsg"></span>
                <?php 
                $successMessage = $this->session->flashdata('successmessage');  
                $warningmessage = $this->session->flashdata('warningmessage');                    
                if (isset($successMessage)) { 
                    echo '<div id="alertmessage" class="col-md-12">
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <span style="margin-left: 40%;">'. $successMessage.'</span>
                        </div>
                    </div>'; 
                } 
                if (isset($warningmessage)) { 
                    echo '<div id="alertmessage" class="col-md-12">
                        <div class="alert alert-warning alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <span style="margin-left: 40%;">'. $warningmessage.'</span>
                        </div>
                    </div>'; 
                }
                ?>
            </div>
        </div>

        <div class="col-md-6">
            <form id="booking" method="POST" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/book">
                <section id="Search" class="LB XXCN P20">
                    <h1 class="bookTic XCN TextSemiBold"><?= output($data['s_companyname']); ?></h1>
                    <div class="searchRow clearfix">
                        <div class="LB">
                            <label class="inputLabel">From</label>
                            <input id="t_trip_fromlocation" name="t_trip_fromlocation" class="XXinput searching" placeholder="Enter From" type="text" tabindex="1" required/>
                            <div id="from-suggestions" class="autocomplete-dropdown"></div>
                        </div>
                        <span class="switchButton" id="switchButton"></span>
                        <div class="searchRight NoPaddingRight">
                            <label class="inputLabel">To</label>
                            <input id="t_trip_tolocation" name="t_trip_tolocation" class="XXinput searching" placeholder="Enter To" type="text" tabindex="2" required />
                            <div id="to-suggestions" class="autocomplete-dropdown"></div>
                        </div>
                    </div>
                    <div class="searchRow clearfix">
                        <div class="LB" style="margin-top: 0px;">
                            <label class="inputLabel">Vehicle Type</label>
                            <select style="height: 32px; margin-top: -1px;" required id="t_vechicle" class="XXinput searching" name="t_vechicle">
                                <option value="">Select vehicle</option>
                                <?php foreach ($vechiclelist as $key => $vechiclelists) { ?>
                                <option value="<?php echo output($vechiclelists['v_id']) ?>">
                                    <?php echo output($vechiclelists['v_name']).' - '. output($vechiclelists['v_registration_no']); ?>
                                </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="searchRight retJouney">
                            <label class="inputLabel">Date</label>
                            <input id="t_start_date" name="t_start_date" class="datepicker XXinput" required placeholder="yyyy-mm-dd" type="text" title="Date in the format yyyy-mm-dd" tabindex="3">
                        </div>
                    </div>
                    <input type="hidden" id="t_trip_fromlat" name="t_trip_fromlat" value="">
                    <input type="hidden" id="t_totaldistance" name="t_totaldistance" value="">
                    <input type="hidden" id="t_trip_fromlog" name="t_trip_fromlog" value="">
                    <input type="hidden" id="t_driver" name="t_driver" value="0">
                    <input type="hidden" id="t_type" name="t_type" value="singletrip">
                    <input type="hidden" id="t_trip_status" name="t_trip_status" value="yettoconfirm">
                    <input type="hidden" id="t_customer_id" name="t_customer_id" value="<?= (isset($this->session->userdata['session_data_fr']['c_id'])?$this->session->userdata['session_data_fr']['c_id']:''); ?>">
                    <input type="hidden" id="t_trip_tolat" name="t_trip_tolat" value="">
                    <input type="hidden" id="t_trip_tolog" name="t_trip_tolog" value="">
                    <input type="hidden" id="t_created_by" name="t_created_by" value="<?= (isset($this->session->userdata['session_data_fr']['c_id'])?$this->session->userdata['session_data_fr']['c_id']:''); ?>">
                    <input type="hidden" id="bookingemail" name="bookingemail" value="<?= (isset($this->session->userdata['session_data_fr']['c_email'])?$this->session->userdata['session_data_fr']['c_email']:''); ?>">
                    <input type="hidden" id="t_created_date" name="t_created_date" value="<?php echo date('Y-m-d h:i:s'); ?>">

                    <button type="submit" class="RB Xbutton">Book Now</button>
                </section>
            </form>
        </div>
        <div class="col-md-6">
            <div id="map"></div>
            <div id="route-info" class="route-info"></div>
        </div>
    </div>
</div>

<hr class="border2">
<div class="container">
    <div class="row">
        <div class="tb_inner">
        </div>
    </div>
</div>

<script src="<?= base_url(); ?>assets/plugins/jquery/jquery_frnt.js"></script>
<script src="<?= base_url(); ?>assets/frontend/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>assets/plugins/datepicker/bootstrap-datepicker.min.js"></script>

<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>

<script src="<?= base_url(); ?>assets/frontendbooking.js"></script>

<script>
// Initialize the map
var map = L.map('map').setView([51.505, -0.09], 13);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Add geocoder control
var geocoder = L.Control.geocoder({
    defaultMarkGeocode: false,
    position: 'topleft',
    placeholder: 'Search for places...'
}).on('markgeocode', function(e) {
    map.fitBounds(e.geocode.bbox);
    map.setZoom(15);
}).addTo(map);

// Variables to store markers and route
var fromMarker, toMarker, route;

// Handle from location input
$('#t_trip_fromlocation').on('input', function() {
    searchLocation(this.value, 'from');
});

// Handle to location input
$('#t_trip_tolocation').on('input', function() {
    searchLocation(this.value, 'to');
});

function searchLocation(query, type) {
    if (query.length < 3) {
        $(`#${type}-suggestions`).hide();
        return;
    }
    
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            const dropdown = $(`#${type}-suggestions`).empty();
            
            if (data.length > 0) {
                data.slice(0, 5).forEach(item => {
                    $('<div class="autocomplete-item"></div>')
                        .text(item.display_name)
                        .click(function() {
                            $(`#t_trip_${type}location`).val(item.display_name);
                            $(`#t_trip_${type}lat`).val(item.lat);
                            $(`#t_trip_${type}log`).val(item.lon);
                            dropdown.hide();
                            
                            // Place marker on map
                            const markerOptions = {
                                riseOnHover: true,
                                title: item.display_name
                            };
                            
                            if (type === 'from') {
                                if (fromMarker) map.removeLayer(fromMarker);
                                fromMarker = L.marker([item.lat, item.lon], markerOptions)
                                    .addTo(map)
                                    .bindPopup("<b>From:</b> " + item.display_name);
                            } else {
                                if (toMarker) map.removeLayer(toMarker);
                                toMarker = L.marker([item.lat, item.lon], markerOptions)
                                    .addTo(map)
                                    .bindPopup("<b>To:</b> " + item.display_name);
                            }
                            
                            // Calculate distance if both points exist
                            if (fromMarker && toMarker) {
                                calculateDistance();
                            }
                        })
                        .appendTo(dropdown);
                });
                dropdown.show();
            } else {
                dropdown.hide();
            }
        })
        .catch(error => {
            console.error('Geocoding error:', error);
        });
}

function calculateDistance() {
    const fromLat = $('#t_trip_fromlat').val();
    const fromLng = $('#t_trip_fromlog').val();
    const toLat = $('#t_trip_tolat').val();
    const toLng = $('#t_trip_tolog').val();
    
    if (fromLat && fromLng && toLat && toLng) {
        // Use OSRM for proper routing
        fetch(`https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full`)
            .then(response => response.json())
            .then(data => {
                if (data.routes && data.routes[0]) {
                    const distance = data.routes[0].distance / 1000; // Convert to km
                    $('#t_totaldistance').val(distance.toFixed(2));
                    $('#route-info').html(`
                        <strong>Distance:</strong> ${distance.toFixed(2)} km<br>
                        <strong>Estimated Duration:</strong> ${(data.routes[0].duration / 60).toFixed(0)} minutes
                    `);
                    
                    // Draw the route
                    if (route) map.removeLayer(route);
                    const routeCoordinates = data.routes[0].geometry.coordinates.map(coord => [coord[1], coord[0]]);
                    route = L.polyline(routeCoordinates, {
                        color: '#3388ff',
                        weight: 5,
                        opacity: 0.7
                    }).addTo(map);
                    
                    // Fit map to show the entire route
                    map.fitBounds(route.getBounds());
                }
            })
            .catch(error => {
                console.error('Routing error:', error);
                // Fallback to simple distance calculation
                const R = 6371; // Earth's radius in km
                const dLat = (toLat - fromLat) * Math.PI / 180;
                const dLng = (toLng - fromLng) * Math.PI / 180;
                const a = 
                    Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(fromLat * Math.PI / 180) * Math.cos(toLat * Math.PI / 180) * 
                    Math.sin(dLng/2) * Math.sin(dLng/2);
                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                const distance = R * c;
                
                $('#t_totaldistance').val(distance.toFixed(2));
                $('#route-info').html(`<strong>Distance:</strong> ${distance.toFixed(2)} km`);
                
                // Draw straight line as fallback
                if (route) map.removeLayer(route);
                route = L.polyline([
                    [fromLat, fromLng],
                    [toLat, toLng]
                ], {color: '#3388ff'}).addTo(map);
                
                map.fitBounds([
                    [fromLat, fromLng],
                    [toLat, toLng]
                ]);
            });
    }
}
</script>
</body>
</html> -->



<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php 
        $data = sitedata();
        $total_segments = $this->uri->total_segments(); 
        echo ucwords(str_replace('_', ' ', 'Booking')).' | '.output($data['s_companyname']) ?></title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?= base_url(); ?>assets/frontend/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/frontend/font-awesome.min.css">
    <link href="<?= base_url(); ?>assets/frontend/custom.css" rel="stylesheet">
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
    <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/datepicker/bootstrap-datepicker.min.css">
    <style>
        #map {
            height: 400px;
            width: 100%;
            border-radius: 4px;
            box-shadow: 0 1px 5px rgba(0,0,0,0.2);
            margin-top: 10px;
        }
        .autocomplete-dropdown {
            position: absolute;
            background: white;
            z-index: 1000;
            width: calc(100% - 30px);
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ddd;
            display: none;
        }
        .autocomplete-item {
            padding: 8px;
            cursor: pointer;
        }
        .autocomplete-item:hover {
            background-color: #f5f5f5;
        }
        .route-info {
            margin-top: 10px;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        .close_lft {
            position: absolute;
            right: 10px;
            top: 10px;
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
        }
        .login-block {
            padding: 20px;
            text-align: center;
        }
        .sign_in, .account {
            margin-top: 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
<input type="hidden" id="base" value="<?php echo base_url(); ?>">

<!-- HEADER-BAR -->
<div class="tb_header">
    <div class="container">
        <div class="col-md-6" style="padding:0;">
            <div style="margin-top: 20px;"> <img heigth="80" width="50" src="<?= base_url().'assets/uploads/'.$data['s_logo'] ?>"> </div>
        </div>
        <div class="col-md-4" style="padding:0;">
        </div>
        <div class="col-md-2" style="padding:0;">
            <?php if(isset($this->session->userdata['session_data_fr']['c_name'])) { ?>
                <div class="signin_up">
                <ul>
                    <li>Welcome , <?= ucfirst($this->session->userdata['session_data_fr']['c_name']); ?> </li><br>
                    <li><a href="<?php echo base_url(); ?>frontendbooking/mybookings">My Bookings</a>  <span style="color:#f0a2a3;">/</span></li>
                    <li><a href="<?php echo base_url(); ?>frontendbooking/logout">Logout</a></li>
                </ul>
            </div>
            <?php  } else { ?>
            <div class="signin_up">
                <ul>
                    <li><a href="#myModals" data-toggle="modal" data-target="#myModals">Sign In</a>  <span style="color:#f0a2a3;">/</span></li>
                    <li><a href="#myModal" data-toggle="modal" data-target="#myModal">Sign Up</a></li>
                </ul>
            </div>
        <?php  } ?>
        </div>
    </div>
    <div class="shadow">
        <hr class="border2">
        </hr>
    </div>
</div>

<!-- SIGN IN MODAL -->
<div class="modal fade" id="myModals" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
        <button type="button" class="close_lft" data-dismiss="modal">&times;</button>
        <form id="login" method="post" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/login">
            <div class="login-block">
                <h1>Login</h1>
                <input type="text" required name="username" placeholder="Email" class ="username" id="username" required=""/>
                <input type="password" required class="password" name="password" placeholder="Password" id="password" required=""/>
                <button type="submit" value="Login" style="position: relative;">Login</button>
                <br>
                
                <div class="login_res" style="text-align:center;"></div>
                <br>
                <div class="sign_in"><a data-dismiss="modal" href="#myModal" data-toggle="modal" data-target="#myModal">Sign Up</a></div>
            </div>
        </form>
    </div>
</div>

<!-- SIGN UP MODAL -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close_lft" data-dismiss="modal">&times;</button>
        <form id="signup" method="post" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/signup">
            <div class="login-block">
                <h1>Sign Up</h1>
                <input class="name" required id="c_name" name="c_name" placeholder="Name">
                <input class="name" required id="c_mobile" name="c_mobile" placeholder="Mobile">
                <input class="name" required id="c_email" name="c_email" placeholder="Email(Username)">
                <input type="password" required class="name" id="c_pwd" name="c_pwd" placeholder="Password">
                <input class="name" required id="c_address" name="c_address" placeholder="Address">
                <br>
                <span class="terms_tb">By signing up, you agree to our <a class="cond_tb" href="#">Terms and Conditions.</a></span> <br>
                <br>
                <button type="submit" value="Sign up" style="position: relative;">Sign UP</button>
                <br>
               
                <div class="signup_res" style="text-align:center;"></div>
                <br>
                <div class="account"><a data-dismiss="modal" href="#myModals"data-toggle="modal" data-target="#myModals">Already have an account?</a></div>
                <div class="sign_in"><a data-dismiss="modal" href="#myModals"data-toggle="modal" data-target="#myModals">Sign In</a></div>
            </div>
        </form>
    </div>
</div>

<!-- FORGOT PASSWORD MODAL -->
<div class="modal fade" id="myModalf" role="dialog">
    <div class="modal-dialog">
        <button type="button" class="close_lft" data-dismiss="modal">&times;</button>
        <form id="forgot" data-parsley-validate="">
            <div class="login-block">
                <h1>Forgot Password</h1>
                <input type="email" name="email" placeholder="Email" class="username" data-parsley-required="true"/>
                <input type="button" value="RESET" style="position: relative;" onclick="Forgot()">
                <br>
                <div class="small_loader" style="text-align:center;display:none"></div>
                <div class="forgot_res" style="text-align:center;"></div>
                <br>
                <div class="account"><a href="#">Already have an account?</a></div>
                <div class="sign_in"><a data-dismiss="modal" href="#myModals"data-toggle="modal" data-target="#myModals">Sign In</a></div>
            </div>
        </form>
    </div>
</div>

<!-- Main Content -->
<div class="container">
    <div class="row" style="min-height:400px;margin-top:120px;">
        <div class="row">
            <div class="col-md-12">
                <span id="ermsg"></span>
                <?php 
                $successMessage = $this->session->flashdata('successmessage');  
                $warningmessage = $this->session->flashdata('warningmessage');                    
                if (isset($successMessage)) { 
                    echo '<div id="alertmessage" class="col-md-12">
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <span style="margin-left: 40%;">'. $successMessage.'</span>
                        </div>
                    </div>'; 
                } 
                if (isset($warningmessage)) { 
                    echo '<div id="alertmessage" class="col-md-12">
                        <div class="alert alert-warning alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <span style="margin-left: 40%;">'. $warningmessage.'</span>
                        </div>
                    </div>'; 
                }
                ?>
            </div>
        </div>

        <div class="col-md-6">
            <form id="booking" method="POST" class="basicvalidation" action="<?php echo base_url();?>frontendbooking/book">
                <section id="Search" class="LB XXCN P20">
                    <h1 class="bookTic XCN TextSemiBold"><?= output($data['s_companyname']); ?></h1>
                    <div class="searchRow clearfix">
                        <div class="LB">
                            <label class="inputLabel">From</label>
                            <input id="t_trip_fromlocation" name="t_trip_fromlocation" class="XXinput searching" placeholder="Enter From" type="text" tabindex="1" required/>
                            <div id="from-suggestions" class="autocomplete-dropdown"></div>
                        </div>
                        <span class="switchButton" id="switchButton"></span>
                        <div class="searchRight NoPaddingRight">
                            <label class="inputLabel">To</label>
                            <input id="t_trip_tolocation" name="t_trip_tolocation" class="XXinput searching" placeholder="Enter To" type="text" tabindex="2" required />
                            <div id="to-suggestions" class="autocomplete-dropdown"></div>
                        </div>
                    </div>
                    <div class="searchRow clearfix">
                        <div class="LB" style="margin-top: 0px;">
                            <label class="inputLabel">Vehicle Type</label>
                            <select style="height: 32px; margin-top: -1px;" required id="t_vechicle" class="XXinput searching" name="t_vechicle">
                                <option value="">Select vehicle</option>
                                <?php foreach ($vechiclelist as $key => $vechiclelists) { ?>
                                <option value="<?php echo output($vechiclelists['v_id']) ?>">
                                    <?php echo output($vechiclelists['v_name']).' - '. output($vechiclelists['v_registration_no']); ?>
                                </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="searchRight retJouney">
                            <label class="inputLabel">Date</label>
                            <input id="t_start_date" name="t_start_date" class="datepicker XXinput" required placeholder="yyyy-mm-dd" type="text" title="Date in the format yyyy-mm-dd" tabindex="3">
                        </div>
                    </div>
                    <input type="hidden" id="t_trip_fromlat" name="t_trip_fromlat" value="">
                    <input type="hidden" id="t_totaldistance" name="t_totaldistance" value="">
                    <input type="hidden" id="t_trip_fromlog" name="t_trip_fromlog" value="">
                    <input type="hidden" id="t_driver" name="t_driver" value="0">
                    <input type="hidden" id="t_type" name="t_type" value="singletrip">
                    <input type="hidden" id="t_trip_status" name="t_trip_status" value="yettoconfirm">
                    <input type="hidden" id="t_customer_id" name="t_customer_id" value="<?= (isset($this->session->userdata['session_data_fr']['c_id'])?$this->session->userdata['session_data_fr']['c_id']:''); ?>">
                    <input type="hidden" id="t_trip_tolat" name="t_trip_tolat" value="">
                    <input type="hidden" id="t_trip_tolog" name="t_trip_tolog" value="">
                    <input type="hidden" id="t_created_by" name="t_created_by" value="<?= (isset($this->session->userdata['session_data_fr']['c_id'])?$this->session->userdata['session_data_fr']['c_id']:''); ?>">
                    <input type="hidden" id="bookingemail" name="bookingemail" value="<?= (isset($this->session->userdata['session_data_fr']['c_email'])?$this->session->userdata['session_data_fr']['c_email']:''); ?>">
                    <input type="hidden" id="t_created_date" name="t_created_date" value="<?php echo date('Y-m-d h:i:s'); ?>">

                    <button type="submit" class="RB Xbutton">Book Now</button>
                </section>
            </form>
        </div>
        <div class="col-md-6">
            <div id="map"></div>
            <div id="route-info" class="route-info"></div>
        </div>
    </div>
</div>

<!-- Footer -->
<hr class="border2">
<div class="container">
    <div class="row">
        <div class="tb_inner">
            <div class="col-md-9">
                <div class="tb_footer">
                    <ul>
                        <li><a href="#">FAQ   &nbsp;|</a></li>
                        <li><a href="#">Contact Us   &nbsp;|</a></li>
                        <li><a href="#">Terms of Use   &nbsp;|</a></li>
                        <li><a href="#">Privacy Policy   &nbsp;</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript Files -->
<script src="<?= base_url(); ?>assets/plugins/jquery/jquery_frnt.js"></script>
<script src="<?= base_url(); ?>assets/frontend/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>assets/plugins/datepicker/bootstrap-datepicker.min.js"></script>

<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>

<!-- Custom JS -->
<script src="<?= base_url(); ?>assets/frontendbooking.js"></script>
<script src="<?= base_url(); ?>assets/distance_calculator.js"></script>

<script>
// Initialize the map
var map = L.map('map').setView([51.505, -0.09], 13);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Add geocoder control
var geocoder = L.Control.geocoder({
    defaultMarkGeocode: false,
    position: 'topleft',
    placeholder: 'Search for places...'
}).on('markgeocode', function(e) {
    map.fitBounds(e.geocode.bbox);
    map.setZoom(15);
}).addTo(map);

// Variables to store markers and route
var fromMarker, toMarker, route;

// Handle from location input
$('#t_trip_fromlocation').on('input', function() {
    searchLocation(this.value, 'from');
});

// Handle to location input
$('#t_trip_tolocation').on('input', function() {
    searchLocation(this.value, 'to');
});

function searchLocation(query, type) {
    if (query.length < 3) {
        $(`#${type}-suggestions`).hide();
        return;
    }
    
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            const dropdown = $(`#${type}-suggestions`).empty();
            
            if (data.length > 0) {
                data.slice(0, 5).forEach(item => {
                    $('<div class="autocomplete-item"></div>')
                        .text(item.display_name)
                        .click(function() {
                            $(`#t_trip_${type}location`).val(item.display_name);
                            $(`#t_trip_${type}lat`).val(item.lat);
                            $(`#t_trip_${type}log`).val(item.lon);
                            dropdown.hide();
                            
                            // Place marker on map
                            const markerOptions = {
                                riseOnHover: true,
                                title: item.display_name
                            };
                            
                            if (type === 'from') {
                                if (fromMarker) map.removeLayer(fromMarker);
                                fromMarker = L.marker([item.lat, item.lon], markerOptions)
                                    .addTo(map)
                                    .bindPopup("<b>From:</b> " + item.display_name);
                            } else {
                                if (toMarker) map.removeLayer(toMarker);
                                toMarker = L.marker([item.lat, item.lon], markerOptions)
                                    .addTo(map)
                                    .bindPopup("<b>To:</b> " + item.display_name);
                            }
                            
                            // Calculate distance if both points exist
                            if (fromMarker && toMarker) {
                                calculateDistance();
                            }
                        })
                        .appendTo(dropdown);
                });
                dropdown.show();
            } else {
                dropdown.hide();
            }
        })
        .catch(error => {
            console.error('Geocoding error:', error);
        });
}

function calculateDistance() {
    const fromLat = $('#t_trip_fromlat').val();
    const fromLng = $('#t_trip_fromlog').val();
    const toLat = $('#t_trip_tolat').val();
    const toLng = $('#t_trip_tolog').val();
    
    if (fromLat && fromLng && toLat && toLng) {
        // Use OSRM for proper routing
        fetch(`https://router.project-osrm.org/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}?overview=full`)
            .then(response => response.json())
            .then(data => {
                if (data.routes && data.routes[0]) {
                    const distance = data.routes[0].distance / 1000; // Convert to km
                    $('#t_totaldistance').val(distance.toFixed(2));
                    $('#route-info').html(`
                        <strong>Distance:</strong> ${distance.toFixed(2)} km<br>
                        <strong>Estimated Duration:</strong> ${(data.routes[0].duration / 60).toFixed(0)} minutes
                    `);
                    
                    // Draw the route
                    if (route) map.removeLayer(route);
                    const routeCoordinates = data.routes[0].geometry.coordinates.map(coord => [coord[1], coord[0]]);
                    route = L.polyline(routeCoordinates, {
                        color: '#3388ff',
                        weight: 5,
                        opacity: 0.7
                    }).addTo(map);
                    
                    // Fit map to show the entire route
                    map.fitBounds(route.getBounds());
                }
            })
            .catch(error => {
                console.error('Routing error:', error);
                // Fallback to simple distance calculation
                const R = 6371; // Earth's radius in km
                const dLat = (toLat - fromLat) * Math.PI / 180;
                const dLng = (toLng - fromLng) * Math.PI / 180;
                const a = 
                    Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(fromLat * Math.PI / 180) * Math.cos(toLat * Math.PI / 180) * 
                    Math.sin(dLng/2) * Math.sin(dLng/2);
                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
                const distance = R * c;
                
                $('#t_totaldistance').val(distance.toFixed(2));
                $('#route-info').html(`<strong>Distance:</strong> ${distance.toFixed(2)} km`);
                
                // Draw straight line as fallback
                if (route) map.removeLayer(route);
                route = L.polyline([
                    [fromLat, fromLng],
                    [toLat, toLng]
                ], {color: '#3388ff'}).addTo(map);
                
                map.fitBounds([
                    [fromLat, fromLng],
                    [toLat, toLng]
                ]);
            });
    }
}

// Initialize datepicker
$('.datepicker').datepicker({
    format: 'yyyy-mm-dd',
    autoclose: true
});

// Forgot password function
function Forgot() {
    var email = $('input[name="email"]').val();
    if (email == '') {
        alert('Please enter email');
        return false;
    }
    
    $('.small_loader').show();
    $('.forgot_res').html('');
    
    $.ajax({
        type: "POST",
        url: $('#base').val() + "frontendbooking/forgot",
        data: {email: email},
        dataType: 'json',
        success: function(response) {
            $('.small_loader').hide();
            if (response.status == 1) {
                $('.forgot_res').html('<div class="alert alert-success">' + response.message + '</div>');
            } else {
                $('.forgot_res').html('<div class="alert alert-danger">' + response.message + '</div>');
            }
        },
        error: function() {
            $('.small_loader').hide();
            $('.forgot_res').html('<div class="alert alert-danger">Error processing request</div>');
        }
    });
}
</script>
</body>
</html>
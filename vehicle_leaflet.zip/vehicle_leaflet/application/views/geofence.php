<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Geofence List</h3>
        <a href="<?= base_url('geofence/addgeofence') ?>" class="btn btn-success pull-right">Add New</a>
      </div>
      <div class="box-body">
        <table id="geofenceTable" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Geofence Name</th>
              <th>Vehicles</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if(!empty($geofencelist)): ?>
              <?php foreach($geofencelist as $geofence): ?>
                <tr>
                  <td><?= $geofence['geo_name'] ?></td>
                  <td><?= $geofence['geo_vehiclename'] ?></td>
                  <td>
                    <a href="javascript:void(0)" onclick="viewGeofence(<?= $geofence['geo_id'] ?>)" class="btn btn-info btn-xs">
                      <i class="fa fa-eye"></i> View
                    </a>
                    <a href="<?= base_url('geofence/geofencedelete/'.$geofence['geo_id']) ?>" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure?')">
                      <i class="fa fa-trash"></i> Delete
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Modal for viewing geofence -->
<div class="modal fade" id="geofenceModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title">Geofence Details</h4>
      </div>
      <div class="modal-body">
        <div id="geofenceMap" style="height: 500px; width: 100%;"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Include Leaflet CSS/JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

<script>
$(document).ready(function() {
  $('#geofenceTable').DataTable();
});

function viewGeofence(geoId) {
  $.post('<?= base_url("geofence/geofence_get") ?>', {id: geoId}, function(response) {
    if(response && response.length > 0) {
      $('#geofenceModal').modal('show');
      
      // Initialize map if not already initialized
      if (!$('#geofenceMap').data('map')) {
        var map = L.map('geofenceMap').setView([24.8998373, 91.8258764], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        $('#geofenceMap').data('map', map);
      }
      
      var map = $('#geofenceMap').data('map');
      map.eachLayer(function(layer) {
        if (layer instanceof L.Polygon) {
          map.removeLayer(layer);
        }
      });
      
      // Create polygon from coordinates
      var polygon = L.polygon(response, {
        color: '#3388ff',
        weight: 2,
        opacity: 1,
        fillColor: '#3388ff',
        fillOpacity: 0.45
      }).addTo(map);
      
      // Fit bounds to the polygon
      map.fitBounds(polygon.getBounds());
    } else {
      alert('Geofence not found or invalid coordinates');
    }
  }, 'json');
}
</script>
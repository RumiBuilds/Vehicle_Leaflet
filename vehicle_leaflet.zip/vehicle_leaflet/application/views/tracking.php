    <div class="content-header">
  <div class="container-fluid">
    <form id="track" method="post">
      <div class="row col-md-12">
        <div class="col-md-2">
          <div class="form-group">
            <input type="text" required="true" name="fromdate" id="fromdate" class="form-control datepicker" placeholder="From Date">
          </div>
        </div>
        <div class="col-sm-2">
          <div class="form-group">
            <input type="text" required="true" name="todate" id="todate" class="form-control datepicker" placeholder="To Date">
          </div>
        </div>
        <div class="col-md-5">
          <div class="form-group">
            <select id="t_vechicle" required="true" class="form-control selectized" name="t_vechicle">
              <option value="">Select Vehicle</option>
              <?php foreach ($vechiclelist as $key => $vechiclelists) { ?>
                <option value="<?php echo output($vechiclelists['v_id']) ?>">
                  <?php echo output($vechiclelists['v_name']).' - '. output($vechiclelists['v_registration_no']); ?>
                </option>
              <?php } ?>
            </select>
          </div>
        </div>
        <div class="col-md-3">
          <div class="form-group">
            <button type="submit" class="btn btn-primary">Load</button>
          </div>
        </div>
      </div>
    </form>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row-cards">
          <!-- Leaflet CSS -->
          <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
          <!-- Leaflet plugins CSS -->
          <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css" />
          <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css" />
          
          <div class="col-lg-12 col-md-12" id="trackingMap" style="width: 100%; height: 475px"></div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
</div>

<!-- JavaScript Libraries -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js"></script>
<script src="https://cdn.jsdelivr.net/npm/leaflet.polyline.snakeanim@0.2.0/L.Polyline.SnakeAnim.min.js"></script>

<script>
$(document).ready(function() {
  // Initialize datepickers
  $('.datepicker').datepicker({
    format: 'yyyy-mm-dd',
    autoclose: true
  });

  // Initialize selectize
  $('.selectized').select2();

  // Initialize Leaflet map
  var map = L.map('trackingMap').setView([24.8998373, 91.8258764], 12);
  
  // Add tile layer (OpenStreetMap)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 18
  }).addTo(map);

  // Initialize marker cluster group
  var markers = L.markerClusterGroup();
  map.addLayer(markers);

  // Form submission handler
  $('#track').submit(function(e) {
    e.preventDefault();
    
    var formData = $(this).serialize();
    
    // Clear existing markers
    markers.clearLayers();
    
    // Show loading state
    $('#trackingMap').append('<div class="map-loading">Loading...</div>');
    
    $.ajax({
      url: '<?= base_url("tracking/get_tracking_data") ?>',
      type: 'POST',
      data: formData,
      dataType: 'json',
      success: function(response) {
        $('.map-loading').remove();
        
        if(response.status && response.data.length > 0) {
          // Create polyline coordinates array
          var latlngs = [];
          
          // Add markers for each point
          response.data.forEach(function(point, index) {
            var marker = L.marker([point.latitude, point.longitude], {
              title: point.vehicle_name
            }).bindPopup(
              `<b>${point.vehicle_name}</b><br>
               Date: ${point.date}<br>
               Speed: ${point.speed} km/h`
            );
            
            markers.addLayer(marker);
            latlngs.push([point.latitude, point.longitude]);
          });
          
          // Add polyline with animation
          var polyline = L.polyline(latlngs, {
            color: '#3388ff',
            weight: 5,
            opacity: 0.7
          }).addTo(map);
          
          // Add animation to polyline
          polyline.snakeIn();
          
          // Fit map to show all markers
          map.fitBounds(markers.getBounds());
        } else {
          alert('No tracking data found for the selected criteria');
        }
      },
      error: function() {
        $('.map-loading').remove();
        alert('Error loading tracking data');
      }
    });
  });
});
</script>

<style>
.map-loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0,0,0,0.7);
  color: white;
  padding: 10px 20px;
  border-radius: 5px;
  z-index: 1000;
}
</style>
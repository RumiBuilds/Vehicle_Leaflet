<div class="row">
  <div class="col-md-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">Add Geofence</h3>
      </div>
      <div class="box-body">
        <form id="geofenceform" class="form-horizontal" method="post" action="<?= base_url('geofence/geofence_save') ?>">
          <div class="form-group">
            <label class="col-sm-2 control-label">Geofence Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="geo_name" required>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Vehicles</label>
            <div class="col-sm-10">
              <select class="form-control select2" multiple="multiple" name="geo_vehicles[]" style="width:100%">
                <?php foreach($vehicles as $vehicle): ?>
                  <option value="<?= $vehicle['v_id'] ?>"><?= $vehicle['v_name'] ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Draw Geofence</label>
            <div class="col-sm-10">
              <div id="map" style="height: 500px; width: 100%;"></div>
              <input type="hidden" name="geo_area" id="geo_area">
              <div class="map-controls">
                <button type="button" id="delete-button" class="btn btn-danger btn-sm">
                  <i class="fa fa-trash"></i> Delete Selected
                </button>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-success">Save Geofence</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Include Leaflet and related plugins -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-geosearch@3.0.0/dist/geosearch.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>
<script src="https://unpkg.com/leaflet-geosearch@3.0.0/dist/geosearch.umd.js"></script>

<!-- Custom geofence.js -->
<script>
$(document).ready(function() {
  $('.select2').select2();
  
  // Initialize map and drawing tools (using the code provided earlier)
  var map, drawnItems, selectedShape, searchControl;
  
  function initialize() {
    // Map initialization
    map = L.map('map').setView([24.8998373, 91.8258764], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Initialize feature group
    drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);

    // Drawing control
    var drawControl = new L.Control.Draw({
      edit: { featureGroup: drawnItems },
      draw: {
        polygon: {
          shapeOptions: { color: '#3388ff', fillOpacity: 0.45 },
          allowIntersection: false
        },
        marker: false,
        polyline: false,
        rectangle: false,
        circle: false
      }
    });
    map.addControl(drawControl);

    // Search control
    const provider = new GeoSearch.OpenStreetMapProvider();
    searchControl = new GeoSearch.GeoSearchControl({
      provider: provider,
      style: 'bar',
      showMarker: true,
      showPopup: false
    });
    map.addControl(searchControl);

    // Event listeners
    map.on(L.Draw.Event.CREATED, function(e) {
      var layer = e.layer;
      drawnItems.addLayer(layer);
      layer.on({
        click: function() { setSelection(layer); },
        dragend: function() { updateCurSelText(layer); }
      });
      setSelection(layer, true);
    });

    map.on('draw:editstart', clearSelection);
    map.on('click', clearSelection);
  }

  function setSelection(layer, isShape) {
    clearSelection();
    if (isShape) {
      layer.setStyle({ color: '#ff0000', fillColor: '#ff0000', weight: 3 });
      layer.bringToFront();
    }
    selectedShape = layer;
  }

  function clearSelection() {
    if (selectedShape) {
      drawnItems.eachLayer(function(layer) {
        layer.setStyle({ color: '#3388ff', fillColor: '#3388ff', weight: 2 });
      });
      selectedShape = null;
    }
  }

  function updateCurSelText(layer) {
    if (!layer || !layer.getLatLngs) return;
    var coordinates = [];
    layer.getLatLngs()[0].forEach(function(latLng) {
      coordinates.push(latLng.lat + ',' + latLng.lng);
    });
    $('#geo_area').val(coordinates.join(' , '));
  }

  function deleteSelectedShape() {
    if (selectedShape) {
      map.removeLayer(selectedShape);
      drawnItems.removeLayer(selectedShape);
      selectedShape = null;
      $('#geo_area').val('');
    }
  }

  // Initialize the map
  initialize();

  // Delete button event
  $('#delete-button').click(deleteSelectedShape);
});
</script>
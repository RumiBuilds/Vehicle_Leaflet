<?php
$vehicle_id = $this->uri->segment(3) ?? 0;
?>

<!-- Leaflet CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<!-- Leaflet Realtime for live tracking -->
<link rel="stylesheet" href="https://unpkg.com/leaflet-realtime@2.2.0/dist/leaflet-realtime.css" />

<div class="col-lg-12 col-md-12">
    <div id="liveTrackingMap" style="width: 100%; height: 650px;"></div>
</div>

<!-- JavaScript Libraries -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-realtime@2.2.0/dist/leaflet-realtime.js"></script>
<!-- Custom vehicle icons -->
<script src="<?php echo base_url(); ?>assets/js/leaflet-vehicle-markers.js"></script>

<script>
// Initialize the map
var map = L.map('liveTrackingMap').setView([24.8998373, 91.8258764], 13);

// Add OpenStreetMap base layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19
}).addTo(map);

// Get vehicle ID from PHP
var vehicleId = <?= $vehicle_id ?>;

// Vehicle icon options
var vehicleIcon = L.icon({
    iconUrl: '<?= base_url("assets/images/vehicle-icon.png") ?>',
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    popupAnchor: [0, -16]
});

// Initialize realtime tracking layer
var realtime = L.realtime({
    url: '<?= base_url("tracking/get_live_position") ?>?vehicle_id=' + vehicleId,
    crossOrigin: true,
    type: 'json',
    interval: 10000 // Update every 10 seconds
}, {
    interval: 10 * 1000,
    getFeatureId: function(f) {
        return f.properties.id;
    },
    pointToLayer: function(feature, latlng) {
        return L.marker(latlng, {
            icon: vehicleIcon,
            rotationAngle: feature.properties.heading || 0
        }).bindPopup(
            `<b>${feature.properties.vehicle_name}</b><br>
             Speed: ${feature.properties.speed} km/h<br>
             Last update: ${feature.properties.timestamp}`
        );
    }
}).addTo(map);

// Center map on vehicle when position updates
realtime.on('update', function() {
    var vehicleLayer = realtime.getLayer(vehicleId);
    if (vehicleLayer) {
        map.setView(vehicleLayer.getLatLng(), 15);
        
        // Add moving trail/polyline
        if (!window.vehicleHistory) {
            window.vehicleHistory = L.polyline([], {color: 'blue'}).addTo(map);
        }
        var currentLatLng = vehicleLayer.getLatLng();
        var currentHistory = window.vehicleHistory.getLatLngs();
        currentHistory.push(currentLatLng);
        window.vehicleHistory.setLatLngs(currentHistory);
    }
});

// Error handling
realtime.on('error', function() {
    console.error('Error fetching live position data');
});

// Fullscreen control (optional)
map.addControl(new L.Control.Fullscreen());
</script>

<style>
/* Optional fullscreen styling */
.leaflet-control-fullscreen a {
    background: #fff url(<?= base_url('assets/images/fullscreen.png') ?>) no-repeat 0 0;
    background-size: 26px 52px;
}
#liveTrackingMap {
    border-radius: 4px;
    box-shadow: 0 1px 5px rgba(0,0,0,0.4);
}
</style>
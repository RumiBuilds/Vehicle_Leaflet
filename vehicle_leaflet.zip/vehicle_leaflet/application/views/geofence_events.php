<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Geofence Events</h3>
      </div>
      <div class="box-body">
        <table id="geofenceEventsTable" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Geofence Name</th>
              <th>Vehicle</th>
              <th>Event Type</th>
              <th>Date/Time</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            <?php if(!empty($geofenceevents)): ?>
              <?php foreach($geofenceevents as $event): ?>
                <tr>
                  <td><?= $event['geo_name'] ?? 'N/A' ?></td>
                  <td><?= $event['ge_vehicle_name'] ?? 'N/A' ?></td>
                  <td>
                    <?php if($event['ge_type'] == 'entry'): ?>
                      <span class="label label-success">Entry</span>
                    <?php else: ?>
                      <span class="label label-danger">Exit</span>
                    <?php endif; ?>
                  </td>
                  <td><?= date('d-m-Y H:i:s', strtotime($event['ge_datetime'])) ?></td>
                  <td>
                    <a href="javascript:void(0)" onclick="viewEventLocation(<?= $event['ge_lat'] ?>, <?= $event['ge_lng'] ?>)" class="btn btn-xs btn-info">
                      <i class="fa fa-map-marker"></i> View
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Modal for viewing location -->
<div class="modal fade" id="locationModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title">Event Location</h4>
      </div>
      <div class="modal-body">
        <div id="eventMap" style="height: 500px; width: 100%;"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Include Leaflet CSS/JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

<script>
$(document).ready(function() {
  $('#geofenceEventsTable').DataTable();
});

function viewEventLocation(lat, lng) {
  $('#locationModal').modal('show');
  
  // Initialize map if not already initialized
  if (!$('#eventMap').data('map')) {
    var map = L.map('eventMap').setView([lat, lng], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    $('#eventMap').data('map', map);
  }
  
  var map = $('#eventMap').data('map');
  
  // Clear existing markers
  map.eachLayer(function(layer) {
    if (layer instanceof L.Marker) {
      map.removeLayer(layer);
    }
  });
  
  // Add marker for this event
  L.marker([lat, lng]).addTo(map)
    .bindPopup('Event location')
    .openPopup();
  
  // Center map on marker
  map.setView([lat, lng], 15);
}
</script>
<!-- <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Live Tracking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?= base_url(); ?>assets/dist/css/adminlte.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition ">
    <div class="col-12 col-md-12">
    <nav class="navbar navbar-expand navbar-light">
      <ul class="navbar-nav">
        <li class="nav-item">
             <span class="nav-link"><b>From :</b> <?= $tripdetails['t_trip_fromlocation'] ?></span>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <span class="nav-link"><b>To : </b><?= $tripdetails['t_trip_tolocation'] ?></span>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <span class="nav-link"><b>Vechicle No : </b><?= $tripdetails['t_vechicle_details']->v_registration_no ?></span>
        </li>
         <li class="nav-item d-none d-sm-inline-block">
          <span class="nav-link"><b>Driver : </b><?= (isset($tripdetails['t_driver_details']->d_name))?$tripdetails['t_driver_details']->d_name:'<span class="badge badge-danger">Yet to Assign</span>'; ?></span>
        </li>
      </ul>

    </nav>
    </div>
    <input type="hidden" value="<?= $tripdetails['t_vechicle_details']->v_id ?>" id="v_id" name="v_id">
    <input type="hidden" value="<?= $tripdetails['t_trip_status'] ?>" id="t_trip_status" name="t_trip_status">
    <div class="col-lg-12 col-md-12" id="map_canvas" style="width: 100%; height: 530px"></div>

<?php  $data = sitedata();  ?>
  <input type="hidden" id="base" value="<?php echo base_url(); ?>">
<script src="<?= base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/plugins/toast/toast.min.css" />
 <script src="<?= base_url(); ?>assets/plugins/toast/toast.min.js"></script>
 <script type="text/javascript"
            src="https://maps.google.com/maps/api/js?key=<?php echo $data['s_googel_api_key']; ?>&v=3.21.5a&libraries=drawing&libraries=places,drawing"></script>
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script id="group"  src="<?php echo base_url(); ?>assets/triptracking.js"></script>
  <script src="<?php echo base_url(); ?>assets/fontawesome-markers.min.js"></script>


<div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Information</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
              <p id="msg"></p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary"data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
</div>

</body>
</html> -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Live Tracking</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.4.1/dist/MarkerCluster.Default.css" />
    <style>
        #map_canvas {
            width: 100%;
            height: 530px;
            border-radius: 4px;
            z-index: 1;
        }
        .vehicle-marker {
            background-color: #3388ff;
            border-radius: 50%;
            border: 2px solid white;
            width: 20px;
            height: 20px;
        }
        .vehicle-marker-moving {
            background-color: #ff3333;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body class="hold-transition">
    <div class="col-12 col-md-12">
        <nav class="navbar navbar-expand navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <span class="nav-link"><b>From :</b> <?= $tripdetails['t_trip_fromlocation'] ?></span>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <span class="nav-link"><b>To : </b><?= $tripdetails['t_trip_tolocation'] ?></span>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <span class="nav-link"><b>Vehicle No : </b><?= $tripdetails['t_vechicle_details']->v_registration_no ?></span>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <span class="nav-link"><b>Driver : </b><?= (isset($tripdetails['t_driver_details']->d_name))?$tripdetails['t_driver_details']->d_name:'<span class="badge badge-danger">Yet to Assign</span>'; ?></span>
                </li>
            </ul>
        </nav>
    </div>
    
    <input type="hidden" value="<?= $tripdetails['t_vechicle_details']->v_id ?>" id="v_id" name="v_id">
    <input type="hidden" value="<?= $tripdetails['t_trip_status'] ?>" id="t_trip_status" name="t_trip_status">
    
    <div class="col-lg-12 col-md-12" id="map_canvas"></div>
    
    <!-- Hidden fields and base URL -->
    <?php $data = sitedata(); ?>
    <input type="hidden" id="base" value="<?php echo base_url(); ?>">
    
    <!-- JavaScript Libraries -->
    <script src="<?= base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/plugins/toast/toast.min.css" />
    <script src="<?= base_url(); ?>assets/plugins/toast/toast.min.js"></script>
    
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js"></script>
    
    <!-- Custom Tracking Script -->
    <script>
        // Initialize the map
        const map = L.map('map_canvas').setView([20.5937, 78.9629], 5); // Default to India coordinates
        
        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        // Create a custom vehicle icon
        const vehicleIcon = L.divIcon({
            className: 'vehicle-marker',
            html: '<div style="background-color: #3388ff; border-radius: 50%; border: 2px solid white; width: 20px; height: 20px;"></div>',
            iconSize: [24, 24]
        });
        
        // Create a marker for the vehicle
        let vehicleMarker = null;
        let vehiclePath = L.polyline([], {color: 'blue'}).addTo(map);
        
        // Function to update vehicle position
        function updateVehiclePosition(lat, lng) {
            const newLatLng = L.latLng(lat, lng);
            
            if (!vehicleMarker) {
                // Create marker if it doesn't exist
                vehicleMarker = L.marker(newLatLng, {
                    icon: vehicleIcon,
                    zIndexOffset: 1000
                }).addTo(map);
                
                // Add popup with vehicle info
                vehicleMarker.bindPopup(`
                    <b>Vehicle:</b> <?= $tripdetails['t_vechicle_details']->v_registration_no ?><br>
                    <b>Status:</b> <?= $tripdetails['t_trip_status'] ?>
                `);
            } else {
                // Update existing marker position
                vehicleMarker.setLatLng(newLatLng);
                
                // Add to path
                const currentPath = vehiclePath.getLatLngs();
                currentPath.push(newLatLng);
                vehiclePath.setLatLngs(currentPath);
            }
            
            // Center map on vehicle
            map.setView(newLatLng, 15);
        }
        
        // Poll server for vehicle updates
        function pollVehiclePosition() {
            const vehicleId = $('#v_id').val();
            
            $.ajax({
                url: $('#base').val() + 'tracking/get_vehicle_position/' + vehicleId,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success && response.lat && response.lng) {
                        updateVehiclePosition(response.lat, response.lng);
                    }
                },
                complete: function() {
                    setTimeout(pollVehiclePosition, 5000); // Poll every 5 seconds
                }
            });
        }
        
        // Start polling when page loads
        $(document).ready(function() {
            pollVehiclePosition();
            
            // Add start and end markers if available
            <?php if (!empty($tripdetails['t_trip_fromlat']) && !empty($tripdetails['t_trip_fromlog'])): ?>
                L.marker([<?= $tripdetails['t_trip_fromlat'] ?>, <?= $tripdetails['t_trip_fromlog'] ?>], {
                    icon: L.divIcon({
                        className: 'start-marker',
                        html: '<div style="background-color: #4CAF50; border-radius: 50%; border: 2px solid white; width: 20px; height: 20px;"></div>',
                        iconSize: [24, 24]
                    })
                }).addTo(map).bindPopup("<b>Start:</b> <?= $tripdetails['t_trip_fromlocation'] ?>");
            <?php endif; ?>
            
            <?php if (!empty($tripdetails['t_trip_tolat']) && !empty($tripdetails['t_trip_tolog'])): ?>
                L.marker([<?= $tripdetails['t_trip_tolat'] ?>, <?= $tripdetails['t_trip_tolog'] ?>], {
                    icon: L.divIcon({
                        className: 'end-marker',
                        html: '<div style="background-color: #F44336; border-radius: 50%; border: 2px solid white; width: 20px; height: 20px;"></div>',
                        iconSize: [24, 24]
                    })
                }).addTo(map).bindPopup("<b>Destination:</b> <?= $tripdetails['t_trip_tolocation'] ?>");
            <?php endif; ?>
        });
    </script>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Information</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="msg"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Live Tracking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url(); ?>assets/dist/css/adminlte.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <style>
        #map_canvas {
            width: 100%;
            height: 530px;
            border-radius: 4px;
            z-index: 1;
        }
        .vehicle-marker-icon {
            background: transparent;
            border: none;
            text-shadow: 0 0 2px white, 0 0 5px white;
        }
        .trip-info {
            background: rgba(255,255,255,0.8);
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body class="hold-transition">
    <div class="col-12 col-md-12">
        <nav class="navbar navbar-expand navbar-light bg-white shadow-sm">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <span class="nav-link"><b>From:</b> <?= $tripdetails['t_trip_fromlocation'] ?></span>
                </li>
                <li class="nav-item">
                    <span class="nav-link"><b>To:</b> <?= $tripdetails['t_trip_tolocation'] ?></span>
                </li>
                <li class="nav-item">
                    <span class="nav-link"><b>Vehicle:</b> <?= $tripdetails['t_vechicle_details']->v_registration_no ?></span>
                </li>
                <li class="nav-item">
                    <span class="nav-link"><b>Status:</b> 
                        <span class="badge badge-<?= 
                            ($tripdetails['t_trip_status'] == 'ongoing') ? 'success' : 
                            (($tripdetails['t_trip_status'] == 'completed') ? 'secondary' : 'warning') 
                        ?>">
                            <?= ucfirst($tripdetails['t_trip_status']) ?>
                        </span>
                    </span>
                </li>
            </ul>
        </nav>
    </div>
    
    <input type="hidden" id="v_id" value="<?= $tripdetails['t_vechicle_details']->v_id ?>">
    <input type="hidden" id="t_trip_status" value="<?= $tripdetails['t_trip_status'] ?>">
    <input type="hidden" id="base" value="<?= base_url() ?>">
    
    <div id="map_canvas"></div>
    
    <!-- JavaScript -->
    <script src="<?= base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?= base_url(); ?>assets/js/triptracking.js"></script>
    
    <!-- Modal -->
    <div id="myModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Information</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <p id="msg"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Add this right before the closing </body> tag -->
<script>
    // Pass PHP data to JavaScript safely
    const tripData = {
        markers: <?= json_encode($map_markers) ?>,
        status: '<?= $tripdetails["t_trip_status"] ?>',
        baseUrl: '<?= base_url() ?>'
    };
</script>
</body>
</html>
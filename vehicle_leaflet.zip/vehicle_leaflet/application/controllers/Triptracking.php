<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Triptracking extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper(['form', 'url', 'string']);
        $this->load->library(['form_validation', 'session']);
        $this->load->model(['trips_model', 'vehicle_model']);
    }

    public function index() {
    $trackcode = $this->uri->segment(2);
    $tripdetails = $this->trips_model->getall_trips($trackcode);
    
    $data['tripdetails'] = $tripdetails[0] ?? [];
    
    // Prepare map markers data
    $data['map_markers'] = [
        'start' => [
            'lat' => $tripdetails[0]['t_trip_fromlat'] ?? null,
            'lng' => $tripdetails[0]['t_trip_fromlog'] ?? null,
            'name' => $tripdetails[0]['t_trip_fromlocation'] ?? 'Start Point'
        ],
        'end' => [
            'lat' => $tripdetails[0]['t_trip_tolat'] ?? null,
            'lng' => $tripdetails[0]['t_trip_tolog'] ?? null,
            'name' => $tripdetails[0]['t_trip_tolocation'] ?? 'Destination'
        ],
        'vehicle' => [
            'id' => $tripdetails[0]['t_vechicle_details']->v_id ?? null,
            'name' => $tripdetails[0]['t_vechicle_details']->v_name ?? 'Unknown Vehicle',
            'type' => $tripdetails[0]['t_vechicle_details']->v_type ?? 'TRUCK',
            'color' => $tripdetails[0]['t_vechicle_details']->v_color ?? '#3388ff'
        ]
    ];
    
    $this->load->view('triptracking', $data);
}
     
    public function get_vehicle_position($vehicleId) {
        if(!$this->input->is_ajax_request()) show_404();

        $position = $this->vehicle_model->get_latest_position($vehicleId);
        $vehicle = $this->vehicle_model->get_vehicle_details($vehicleId);

        if($position) {
            $response = [
                'success' => true,
                'lat' => (float)$position->latitude,
                'lng' => (float)$position->longitude,
                'timestamp' => date('Y-m-d H:i:s', strtotime($position->timestamp)),
                'speed' => $position->speed ?? 0,
                'v_name' => $vehicle->v_name ?? 'Unknown',
                'v_type' => $vehicle->v_type ?? 'TRUCK',
                'v_color' => $vehicle->v_color ?? '#3388ff',
                'heading' => $position->heading ?? null
            ];
        } else {
            $response = [
                'success' => false,
                'message' => 'No position data available'
            ];
        }

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracking extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function index()
    {
        $this->load->model('trips_model');
        $data['vechiclelist'] = $this->trips_model->getall_vechicle();
        $this->template->template_render('tracking',$data);
    }

    public function livestatus()
    {
        // No need to check for Google API key anymore
        $this->template->template_render('livelocation');
    }

// Add this new method for API endpoint
public function get_live_position()
{
    $vehicle_id = $this->input->get('vehicle_id');
    // Your logic to get live position data
    $data = $this->your_model->get_live_position($vehicle_id);
    
    // Return as GeoJSON
    header('Content-Type: application/json');
    echo json_encode([
        'type' => 'Feature',
        'geometry' => [
            'type' => 'Point',
            'coordinates' => [$data['longitude'], $data['latitude']]
        ],
        'properties' => [
            'id' => $data['v_id'],
            'vehicle_name' => $data['v_name'],
            'speed' => $data['speed'],
            'heading' => $data['heading'],
            'timestamp' => $data['time']
        ]
    ]);
}
}